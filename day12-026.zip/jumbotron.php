<style>
    .mys{
        /*background-color: rgb(255, 118, 118);*/
        background-image:url("12.jpg");
        padding:50px;
    }
    .mys h1{
        color: black;
        text-shadow: 4px 4px 8px white;
    }
    .mys h5{
        color: black;
        text-shadow: 2px 2px 3px white;
    }

</style>
<div class="Jumbotron text-center bg-info mys " style="margin-bottom:0">
        <h1>MINIMALIST ART</h1>
        <h5>มินิมอลลิสม์ : ศิลปะแห่งการลดทอนวัตถุ</h5>
    </div>