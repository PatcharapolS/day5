<body>

<?php include_once 'head.php'?>

<?php include_once 'nav.php' ?>

<?php include_once 'jumbotron.php'?>


<div class="container" style="margin-top:30px">

  <div class="row">
    <div class="col-sm-4" style="background-color:#f1f8e9 " ><br><br>
    <img class="image" style="center" src="3.png"><br><br>
    <h2 class="text-warning" style="center" > Spiral Jetty (1970)</h2><br>
    </div>
    <div class="col-sm-8">
    <h4>ผลงานของ โรเบิร์ต สมิธสัน (Robert Smithson) ที่ก่อให้เกิดความท้าทายอย่างมากต่อแนวคิดเดิมๆ ของงานประติมากรรม และขยายขอบเขตทางสุนทรียะแบบมินิมอลลิสม์</h4><br>
   
  </div>
  </div>
</div>

<?php include_once 'footer.php'?>
</body>
</html>


