<nav class="navbar navbar-expand-sm bg-success navbar-dark">
<a class="navbar-brand" href="login.php">LOGIN</a>
  <a class="navbar-brand" href="index.php">HOME</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
      
    <ul class="navbar-nav">

    <li class="nav-item">
        <a class="nav-link" href="page1.php">page1</a>
      </li>
      </li>

    <li class="nav-item">
        <a class="nav-link" href="page2.php">page2</a>
      </li>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="page3.php">page3</a>
      </li>
       
    </li>  
    </ul>
  </div>  
</nav>