<body>

<?php include_once 'head.php'?>

<?php include_once 'nav.php' ?>

<?php include_once 'jumbotron.php'?>


<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4"style="background-color:#f1f8e9 " ><br><br>
    <img class="image" style="center" src="1.png"><br><br>
    <h2 class="text-warning" style="center" >Black Paintings</h2><br>
    </div>
    <div class="col-sm-8">
    <h4>แฟรงค์ สเตลลา (Frank Stella) ศิลปินแอ็บสแตร็กต์เอ็กซ์เพรสชันนิสม์ ได้มีผลงานจิตรกรรมอย่าง Black Paintings (1958-60)</h4><br>
   
  </div>
  </div>
</div>

<?php include_once 'footer.php'?>
</body>
</html>