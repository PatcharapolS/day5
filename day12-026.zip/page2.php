<body>

<?php include_once 'head.php'?>

<?php include_once 'nav.php' ?>

<?php include_once 'jumbotron.php'?>


<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4" style="background-color:#f1f8e9 " ><br><br>
    <img class="image" style="center" src="2.png"><br><br>
    <h2 class="text-warning" style="center" >Steel Zinc Plain</h2><br>
    </div>
    <div class="col-sm-8">
    <h4>คาร์ล อังเดร (Carl Andre) ศิลปินชาวอเมริกันผู้เป็นที่รู้จักจากผลงานประติมากรรมแผ่นโลหะสี่เหลี่ยมหน้าตาธรรมดาสามัญที่วางเรียงเป็นตารางหรือแถวตรงอันเรียบง่ายธรรมดา </h4><br>
   
  </div>
  </div>
</div>

<?php include_once 'footer.php'?>
</body>
</html>