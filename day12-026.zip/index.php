<body>

<?php include_once 'head.php'?>

<?php include_once 'nav.php' ?>

<?php include_once 'jumbotron.php'?>


<div class="container" style="margin-top:30px">
  <div class="row">
  <div class="container" style="margin-top:30px">
    <div text-align="center">
        <style>
        .border-box {
        background-color: #eee;
        border: 1px solid #ccc;
        box-shadow: 0 0 2px rgba(0,0,0,0.2);
        border-radius: 2px;
        padding:20px;
        padding-bottom: 60px;
        margin-left: 190px;
        margin-right: 390px;
        margin-bottom: 30px;
        }

        </style>
      </div>
    </div>
  </div>

</div>

<div class="border-box">
        <img text-align="center" src="117.jpg">
        
        </div>
    <div class="container text-center" style="margin-top:30px">
    <h1 class="text-danger">สไตล์มินิมอล</h1><br>
    <h3>ถูกนำมาใช้กับงานศิลปะ หรือการผลิตสินค้าที่มีดีไซน์แบบมินิมอล ซึ่งหมายถึงการลดทอนสีสัน</h3><br>
    <h3> ลดทอนรูปทรง ให้ดูเรียบง่าย ไม่ซับซ้อน สีสันแบบขาว ดำหรือสีเอิร์ธโทน สินค้าต่างๆ</h3><br>
    <h3> ที่ถูกดีไซน์ให้เป็นสไตล์มินิมอล มีตั้งแต่เครื่องเขียนของใช้ในครัวไปจนถึง</h3><br>
    <h3>อุปกรณ์อิเล็กทรอนิกส์อย่างแบรนด์ที่เราคุ้นตาคือ Apple ก็ใช้ดีไซน์แบบมินิมอล</h3>
  </div>
</div>
  </div>
  </div>
</div>

<?php include_once 'footer.php'?>
</body>
</html>