<style>
    .ft{
        padding-top:10px;
        padding-bottom:10px;
    }
</style>

<div class="jambotron text-center bg-success text-white" style="margin-bottom:0;">
<div class="row">

    <div class="col-sm-12">
    <span class="ft">
        นายพชรพล สวัสดีมงคล
    </span>
    </div>

    <div class="col-sm-12">
    <span class ="ft">
         ปวส.1/3 รหัส 026 
    </span >
</div>

</div>
</div>